"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["client.about"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      charge: 1,
      project: undefined,
      supported_platform: window.supported_platform
    };
  },
  components: {},
  mounted: function mounted() {},
  methods: {},
  watch: {}
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\nh6{\n    color: #fff;\n    font-weight: bold;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AboutUsComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/client/views/page/AboutUsComponent.vue":
/*!*************************************************************!*\
  !*** ./resources/js/client/views/page/AboutUsComponent.vue ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AboutUsComponent_vue_vue_type_template_id_07b14d2b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AboutUsComponent.vue?vue&type=template&id=07b14d2b& */ "./resources/js/client/views/page/AboutUsComponent.vue?vue&type=template&id=07b14d2b&");
/* harmony import */ var _AboutUsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AboutUsComponent.vue?vue&type=script&lang=js& */ "./resources/js/client/views/page/AboutUsComponent.vue?vue&type=script&lang=js&");
/* harmony import */ var _AboutUsComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AboutUsComponent.vue?vue&type=style&index=0&lang=css& */ "./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AboutUsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AboutUsComponent_vue_vue_type_template_id_07b14d2b___WEBPACK_IMPORTED_MODULE_0__.render,
  _AboutUsComponent_vue_vue_type_template_id_07b14d2b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/client/views/page/AboutUsComponent.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/client/views/page/AboutUsComponent.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/client/views/page/AboutUsComponent.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AboutUsComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AboutUsComponent.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/client/views/page/AboutUsComponent.vue?vue&type=template&id=07b14d2b&":
/*!********************************************************************************************!*\
  !*** ./resources/js/client/views/page/AboutUsComponent.vue?vue&type=template&id=07b14d2b& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_template_id_07b14d2b___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_template_id_07b14d2b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AboutUsComponent_vue_vue_type_template_id_07b14d2b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AboutUsComponent.vue?vue&type=template&id=07b14d2b& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=template&id=07b14d2b&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=template&id=07b14d2b&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/AboutUsComponent.vue?vue&type=template&id=07b14d2b& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("section", { staticClass: "banner" }, [
      _c("h1", { staticStyle: { "text-align": "center" } }, [
        _vm._v(_vm._s(_vm.$route.meta.title)),
      ]),
    ]),
    _vm._v(" "),
    _vm._m(0),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      { staticClass: "container-fluid pl-5 pr-5 mt-5 pb-5 mb-2" },
      [
        _c("div", { staticClass: "wrapper pl-4 pr-5 mt-5" }, [
          _c(
            "h2",
            {
              staticClass: "vc_custom_heading",
              staticStyle: {
                "text-align": "left",
                "font-family": "Lato",
                "font-weight": "700",
                "font-style": "normal",
              },
            },
            [_vm._v("Invest in Cryptocurrencies of the Future")]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "wpb_text_column" }, [
            _c("div", { staticClass: "wpb_wrapper" }, [
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "MoonSpark is a listing platform focused on providing investors with access to exciting emerging projects. Our platform’s main objective is to make investing in small or micro cap crypto projects more accessible to investors. The biggest gripe we hear among investors interested in the micro cap space is the difficulty of buying into projects. Many investors don’t feel comfortable buying through decentralized exchanges (DEXs) and many others have had bad experiences dealing with exchanges operating in the small cap arena. We plan to change all that."
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "CryptoQuestion has established a solid reputation in the micro cap crypto market with its weekly Micro Cap Watch List, Monthly Moonshot Portfolio and various podcasts. Our large and growing community is made up of investors with an interest in emerging crypto projects. Our new platform is a perfect resource for the investor looking to build a portfolio of early stage projects which they can buy easily and cheaply."
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "There are no commissions, fees or spreads payable by the investor."
                  ),
                ]),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "h2",
            {
              staticClass: "vc_custom_heading",
              staticStyle: {
                "text-align": "left",
                "font-family": "Lato",
                "font-weight": "700",
                "font-style": "normal",
              },
            },
            [_vm._v("Providing project founders with choice")]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "wpb_text_column" }, [
            _c("div", { staticClass: "wpb_wrapper" }, [
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "As a project founder one of the most important goals is to gain widespread adoption of their protocol. That means expanding the investor base among as many token holders as possible. With a small cap project that often proves challenging. "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "Whilst decentralized exchanges (DEXs) are valuable to the crypto ecosystem and will continue to grow in importance they are not the best solution for small crypto projects. Every dollar of their native cryptocurrency has to be supported with a dollar in an alternative currency such as ETH, BNB, TUSD etc. When someone sells the  liquidity has to be replenished. Most small projects have limited liquid resources thus restricting them from marketing their project to a wider audience.  "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "Central exchanges on paper overcome this need for liquidity however it is very difficult for a micro project to obtain a listing on a small exchange, there is an upfront cost and the reputation of most small exchanges are appalling deterring many investors from participating."
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "Our platform provides the project founder with options. "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("ol", [
                _c("li", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("It helps projects raise development capital. "),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "It allows projects to expand their token holder base with few restrictions."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("li", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "It provides a solution for founders wanting to sell tokens. "
                    ),
                  ]),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "The project sets the price at which the token is sold on the platform and has control over the token supply, adding and removing at their discretion. "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "Project owners must submit certain information in order to provide a clear and not misleading picture of their project to investors. This includes information about the project, tokenomics and a short video. The project founder specifies the price he or she wants to sell their tokens at, transfers the tokens that they wish to start selling and then presses submit. "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "Once submitted the project will be made available for investors to purchase. "
                  ),
                ]),
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "No commission, fees or spreads will be charged to investors. There will be a commission charged to the project owner and deducted from each transaction.  "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("b", [
                  _vm._v(
                    "Our focus is on simplicity making small projects accessible to all investors."
                  ),
                  _c("br"),
                ]),
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v("To find out more contact us "),
                ]),
                _c(
                  "a",
                  { attrs: { href: "http://chat@cryptoquestion.tech" } },
                  [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v("here"),
                    ]),
                  ]
                ),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "h2",
            {
              staticClass: "vc_custom_heading",
              staticStyle: {
                "text-align": "left",
                "font-family": "Lato",
                "font-weight": "700",
                "font-style": "normal",
              },
            },
            [_vm._v("A bit about CryptoQuestion")]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "wpb_text_column" }, [
            _c("div", { staticClass: "wpb_wrapper" }, [
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "CryptoQuestion is a fast growing platform that provides various resources to crypto enthusiasts. From the weekly podcast "
                  ),
                ]),
                _c(
                  "a",
                  {
                    attrs: {
                      href: "https://cryptoquestion.tech/weekly-podcast/",
                    },
                  },
                  [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v("Moonshot Monday"),
                    ]),
                  ]
                ),
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(" to our weekly "),
                ]),
                _c(
                  "a",
                  {
                    attrs: {
                      href: "https://cryptoquestion.tech/micro-cap-watch-list/",
                    },
                  },
                  [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v("Micro Cap Watch List"),
                    ]),
                  ]
                ),
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(", from the "),
                ]),
                _c(
                  "a",
                  {
                    attrs: {
                      href: "https://cryptoquestion.tech/inside-track/",
                    },
                  },
                  [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v("Inside Track"),
                    ]),
                  ]
                ),
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(" podcasts to our monthly "),
                ]),
                _c(
                  "a",
                  {
                    attrs: {
                      href: "https://cryptoquestion.tech/moonshot-portfolio-september-2021/",
                    },
                  },
                  [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v("Moonshot Portfolio"),
                    ]),
                  ]
                ),
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v("."),
                ]),
              ]),
              _vm._v(" "),
              _c("p", [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "We continue to build our resources and grow our audience. MoonSpark is a natural step in that development. CryptoQuestion has built a reputation for quality research particularly in the field of small cap crypto projects. We understand the investor’s needs in this area and MoonSpark has been established with those needs firmly in mind."
                  ),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]
    )
  },
]
render._withStripped = true



/***/ })

}]);