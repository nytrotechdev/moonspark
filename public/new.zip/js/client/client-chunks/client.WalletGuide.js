"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["client.WalletGuide"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      charge: 1,
      project: undefined,
      base_url: window.base_url,
      supported_platform: window.supported_platform
    };
  },
  components: {},
  mounted: function mounted() {},
  methods: {},
  watch: {}
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\nh6 {\n  color: #fff;\n  font-weight: bold;\n}\nimg{\n  text-align: center;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./WalletGuide.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/client/views/page/WalletGuide.vue":
/*!********************************************************!*\
  !*** ./resources/js/client/views/page/WalletGuide.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _WalletGuide_vue_vue_type_template_id_054ba19a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WalletGuide.vue?vue&type=template&id=054ba19a& */ "./resources/js/client/views/page/WalletGuide.vue?vue&type=template&id=054ba19a&");
/* harmony import */ var _WalletGuide_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WalletGuide.vue?vue&type=script&lang=js& */ "./resources/js/client/views/page/WalletGuide.vue?vue&type=script&lang=js&");
/* harmony import */ var _WalletGuide_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WalletGuide.vue?vue&type=style&index=0&lang=css& */ "./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _WalletGuide_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _WalletGuide_vue_vue_type_template_id_054ba19a___WEBPACK_IMPORTED_MODULE_0__.render,
  _WalletGuide_vue_vue_type_template_id_054ba19a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/client/views/page/WalletGuide.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/client/views/page/WalletGuide.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/client/views/page/WalletGuide.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./WalletGuide.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./WalletGuide.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/client/views/page/WalletGuide.vue?vue&type=template&id=054ba19a&":
/*!***************************************************************************************!*\
  !*** ./resources/js/client/views/page/WalletGuide.vue?vue&type=template&id=054ba19a& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_template_id_054ba19a___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_template_id_054ba19a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_WalletGuide_vue_vue_type_template_id_054ba19a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./WalletGuide.vue?vue&type=template&id=054ba19a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=template&id=054ba19a&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=template&id=054ba19a&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/WalletGuide.vue?vue&type=template&id=054ba19a& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("section", { staticClass: "banner" }, [
      _c("h1", { staticStyle: { "text-align": "center" } }, [
        _vm._v(_vm._s(_vm.$route.meta.title)),
      ]),
    ]),
    _vm._v(" "),
    _c(
      "div",
      {
        staticClass: "container-fluid pl-5 pr-5 mt-5 pb-3 mb-1 overflow-hidden",
      },
      [
        _c("div", { staticClass: "wrapper pl-4 " }, [
          _c("div", { staticClass: "wpb_wrapper" }, [
            _c(
              "h2",
              {
                staticClass: "vc_custom_heading",
                staticStyle: {
                  "text-align": "left",
                  "font-family": "Lato",
                  "font-weight": "700",
                  "font-style": "normal",
                },
              },
              [_vm._v("\n          How to Set Up Your Wallet\n        ")]
            ),
            _vm._v(" "),
            _vm._m(0),
            _vm._v(" "),
            _c(
              "h2",
              {
                staticClass: "vc_custom_heading us_custom_e61c8f64",
                staticStyle: {
                  "text-align": "left",
                  "font-family": "Lato",
                  "font-weight": "700",
                  "font-style": "normal",
                  color: "#ffd700!important",
                  "font-size": "24px!important",
                },
              },
              [
                _vm._v(
                  "\n          1. Set up of your MetaMask Wallet\n        "
                ),
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "wpb_text_column" }, [
              _c("div", { staticClass: "wpb_wrapper" }, [
                _vm._m(1),
                _vm._v(" "),
                _vm._m(2),
                _vm._v(" "),
                _vm._m(3),
                _vm._v(" "),
                _c("p", [
                  _vm._m(4),
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "Once MetaMask is open, you may be prompted to either “Create\n                a Wallet” or “Import wallet.” If you are first setting up your\n                MetaMask account, select the former. If you have a wallet\n                already, you can select “Import wallet” and then you will be\n                asked to input your 12 word seed phrase to link your account;\n                we’ll tackle the seed phrase below."
                    ),
                    _c("br"),
                    _vm._v(" "),
                    _c("div", { staticClass: "d-100 text-center" }, [
                      _c("img", {
                        staticClass: "wp-image-316 size-full aligncenter",
                        attrs: {
                          loading: "lazy",
                          src: _vm.base_url + "/wallet/metamask.jpg",
                          alt: "",
                          width: "636",
                          height: "424",
                          srcset:
                            "\n                    " +
                            _vm.base_url +
                            "/wallet/metamask.jpg         636w,\n                    " +
                            _vm.base_url +
                            "/wallet/metamask-300x200.jpg 300w\n                  ",
                          sizes: "(max-width: 636px) 100vw, 636px",
                        },
                      }),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _vm._m(5),
                _vm._v(" "),
                _vm._m(6),
                _vm._v(" "),
                _vm._m(7),
                _vm._v(" "),
                _vm._m(8),
                _vm._v(" "),
                _vm._m(9),
                _vm._v(" "),
                _vm._m(10),
                _vm._v(" "),
                _c("p"),
                _c("div", { staticClass: "d-100 text-center" }, [
                  _c("img", {
                    staticClass: "size-full wp-image-317 aligncenter",
                    attrs: {
                      loading: "lazy",
                      src: _vm.base_url + "/wallet/secret.jpg",
                      alt: "",
                      width: "512",
                      height: "341",
                      srcset:
                        "\n                  " +
                        _vm.base_url +
                        "/wallet/secret.jpg         512w,\n                  " +
                        _vm.base_url +
                        "/wallet/secret-300x200.jpg 300w\n                ",
                      sizes: "(max-width: 512px) 100vw, 512px",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("p"),
                _vm._v(" "),
                _c("p", [_vm._v(" ")]),
                _vm._v(" "),
                _vm._m(11),
                _vm._v(" "),
                _c("p", [_vm._v(" ")]),
                _vm._v(" "),
                _c("p", [_vm._v(" ")]),
                _vm._v(" "),
                _c("p", [_vm._v(" ")]),
                _vm._v(" "),
                _c("p", [_vm._v(" ")]),
                _vm._v(" "),
                _vm._m(12),
                _vm._v(" "),
                _vm._m(13),
                _vm._v(" "),
                _c("p", [
                  _vm._v(
                    "\n              Again, the most important part of the process is documenting\n              your seed phrase so that you can get into your account from\n              other devices\n            "
                  ),
                ]),
                _vm._v(" "),
                _vm._m(14),
                _vm._v(" "),
                _vm._m(15),
                _vm._v(" "),
                _c("p"),
                _c("div", { staticClass: "d-100 text-center" }, [
                  _c("img", {
                    staticClass: "size-full wp-image-318 aligncenter",
                    attrs: {
                      loading: "lazy",
                      src: _vm.base_url + "/wallet/metamask2.jpg",
                      alt: "",
                      width: "636",
                      height: "424",
                      srcset:
                        "\n                  " +
                        _vm.base_url +
                        "/wallet/metamask2.jpg         636w,\n                  " +
                        _vm.base_url +
                        "/wallet/metamask2-300x200.jpg 300w\n                ",
                      sizes: "(max-width: 636px) 100vw, 636px",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("p"),
                _vm._v(" "),
                _vm._m(16),
                _vm._v(" "),
                _vm._m(17),
                _vm._v(" "),
                _vm._m(18),
                _vm._v(" "),
                _vm._m(19),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "h2",
              {
                staticClass: "vc_custom_heading us_custom_e61c8f64",
                staticStyle: {
                  "text-align": "left",
                  "font-family": "Lato",
                  "font-weight": "700",
                  "font-style": "normal",
                },
              },
              [
                _vm._v(
                  "\n          2. Beginners Guide to Add a Custom Token in MetaMask\n        "
                ),
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "wpb_text_column" }, [
              _c("div", { staticClass: "wpb_wrapper" }, [
                _vm._m(20),
                _vm._v(" "),
                _c("ol", [
                  _vm._m(21),
                  _vm._v(" "),
                  _c(
                    "li",
                    {
                      staticStyle: { "font-weight": "400" },
                      attrs: { "aria-level": "1" },
                    },
                    [
                      _c("span", { staticStyle: { "font-weight": "400" } }, [
                        _vm._v(
                          "You will need to enter Token Contract Address, Token Symbol\n                  and Decimals of Precision. For instance, let’s say you want\n                  to add EOS token to your account. You need to go to web site "
                        ),
                      ]),
                      _vm._m(22),
                      _c("span", { staticStyle: { "font-weight": "400" } }, [
                        _vm._v(
                          ", select link »Tokens« on the right side and click on »View\n                  Tokens«. Click on EOS token and all the info can be found\n                  there."
                        ),
                        _c("br"),
                        _vm._v(" "),
                        _c("div", { staticClass: "d-100 text-center" }, [
                          _c("img", {
                            staticClass: "aligncenter size-full wp-image-320",
                            attrs: {
                              loading: "lazy",
                              src: _vm.base_url + "/wallet/savtbl.jpg",
                              alt: "",
                              width: "604",
                              height: "96",
                              srcset:
                                "\n                      " +
                                _vm.base_url +
                                "/wallet/savtbl.jpg        604w,\n                      " +
                                _vm.base_url +
                                "/wallet/savtbl-300x48.jpg 300w\n                    ",
                              sizes: "(max-width: 604px) 100vw, 604px",
                            },
                          }),
                        ]),
                      ]),
                    ]
                  ),
                  _vm._v(" "),
                  _vm._m(23),
                  _vm._v(" "),
                  _vm._m(24),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _vm._m(25),
            _vm._v(" "),
            _c(
              "h2",
              {
                staticClass: "vc_custom_heading us_custom_e61c8f64",
                staticStyle: {
                  "text-align": "left",
                  "font-family": "Lato",
                  "font-weight": "700",
                  "font-style": "normal",
                },
              },
              [
                _vm._v(
                  "\n          3. How to Connect MetaMask to Binance Smart Chain\n        "
                ),
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "wpb_text_column" }, [
              _c("div", { staticClass: "wpb_wrapper" }, [
                _vm._m(26),
                _vm._v(" "),
                _vm._m(27),
                _vm._v(" "),
                _vm._m(28),
                _c("div", { staticClass: "d-100 text-center" }, [
                  _c("img", {
                    staticClass: "aligncenter size-full wp-image-322",
                    attrs: {
                      loading: "lazy",
                      src: _vm.base_url + "/wallet/unnamed.png",
                      alt: "",
                      width: "714",
                      height: "1204",
                      srcset:
                        "\n                  " +
                        _vm.base_url +
                        "/wallet/unnamed.png          714w,\n                  " +
                        _vm.base_url +
                        "/wallet/unnamed-178x300.png  178w,\n                  " +
                        _vm.base_url +
                        "/wallet/unnamed-607x1024.png 607w\n                ",
                      sizes: "(max-width: 714px) 100vw, 714px",
                    },
                  }),
                ]),
                _c("br"),
                _vm._v(" "),
                _c("strong", [
                  _vm._v("1. Select the “Settings” from the dropdown menu."),
                ]),
                _vm._v(" "),
                _c("p"),
                _vm._v(" "),
                _c("p"),
                _c("div", { staticClass: "d-100 text-center" }, [
                  _c("img", {
                    staticClass: "aligncenter size-full wp-image-323",
                    attrs: {
                      loading: "lazy",
                      src: _vm.base_url + "/wallet/setting.png",
                      alt: "",
                      width: "712",
                      height: "1202",
                      srcset:
                        "\n                  " +
                        _vm.base_url +
                        "/wallet/setting.png          712w,\n                  " +
                        _vm.base_url +
                        "/wallet/setting-178x300.png  178w,\n                  " +
                        _vm.base_url +
                        "/wallet/setting-607x1024.png 607w\n                ",
                      sizes: "(max-width: 712px) 100vw, 712px",
                    },
                  }),
                ]),
                _c("br"),
                _vm._v(
                  "\n              2. On the “Settings” page, locate the “Networks” menu.\n            "
                ),
                _c("p"),
                _vm._v(" "),
                _c("p"),
                _c("div", { staticClass: "d-100 text-center" }, [
                  _c("img", {
                    staticClass: "aligncenter size-full wp-image-324",
                    attrs: {
                      loading: "lazy",
                      src: _vm.base_url + "/wallet/addneteork.png",
                      alt: "",
                      width: "716",
                      height: "1200",
                      srcset:
                        "\n                  " +
                        _vm.base_url +
                        "/wallet/addneteork.png          716w,\n                  " +
                        _vm.base_url +
                        "/wallet/addneteork-179x300.png  179w,\n                  " +
                        _vm.base_url +
                        "/wallet/addneteork-611x1024.png 611w\n                ",
                      sizes: "(max-width: 716px) 100vw, 716px",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("p"),
                _vm._v(" "),
                _vm._m(29),
                _vm._v(" "),
                _vm._m(30),
                _vm._v(" "),
                _c("p"),
                _c("div", { staticClass: "d-100 text-center" }, [
                  _c("img", {
                    staticClass: "aligncenter size-full wp-image-325",
                    attrs: {
                      loading: "lazy",
                      src: _vm.base_url + "/wallet/information.png",
                      alt: "",
                      width: "714",
                      height: "1202",
                      srcset:
                        "\n                  " +
                        _vm.base_url +
                        "/wallet/information.png          714w,\n                  " +
                        _vm.base_url +
                        "/wallet/information-178x300.png  178w,\n                  " +
                        _vm.base_url +
                        "/wallet/information-608x1024.png 608w\n                ",
                      sizes: "(max-width: 714px) 100vw, 714px",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("p"),
                _vm._v(" "),
                _vm._m(31),
                _vm._v(" "),
                _c("p"),
                _c("div", { staticClass: "d-100 text-center" }, [
                  _c("img", {
                    staticClass: "aligncenter size-full wp-image-326",
                    attrs: {
                      loading: "lazy",
                      src: _vm.base_url + "/wallet/bnb.png",
                      alt: "",
                      width: "714",
                      height: "1198",
                      srcset:
                        "\n                  " +
                        _vm.base_url +
                        "/wallet/bnb.png          714w,\n                  " +
                        _vm.base_url +
                        "/wallet/bnb-179x300.png  179w,\n                  " +
                        _vm.base_url +
                        "/wallet/bnb-610x1024.png 610w\n                ",
                      sizes: "(max-width: 714px) 100vw, 714px",
                    },
                  }),
                ]),
                _vm._v(" "),
                _c("p"),
                _vm._v(" "),
                _vm._m(32),
                _vm._v(" "),
                _c("p", [_vm._v(" ")]),
                _vm._v(" "),
                _vm._m(33),
              ]),
            ]),
          ]),
        ]),
      ]
    ),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "wpb_text_column" }, [
      _c("div", { staticClass: "wpb_wrapper" }, [
        _c("p", [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v(
              "Below we have provided you with what we think are\n                straightforward instructions on how to set up your digital\n                wallet. This will allow you to buy the tokens featured on this\n                platform. There is no way around it, we are afraid!"
            ),
          ]),
        ]),
        _vm._v(" "),
        _c("p", [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v(
              "There are a number of reputable wallet providers such as\n                Trust Wallet and MetaMask for example. Our examples are based\n                on the MetaMask Wallet. MetaMask is a household name in the\n                crypto community. Many crypto and NFT fans have been using the\n                wallet since its inception in 2017."
            ),
          ]),
        ]),
        _vm._v(" "),
        _c("p", [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v(
              "MetaMask is a software cryptocurrency wallet that interacts\n                with the Ethereum blockchain. It has multiple use cases, like\n                storing cryptocurrencies such as ETH, ERC-20 tokens and even\n                NFTs. MetaMask can even be used to swap tokens inside the\n                application itself."
            ),
          ]),
        ]),
        _vm._v(" "),
        _c("p", [_c("strong", [_vm._v("We are going to show you how to:")])]),
        _vm._v(" "),
        _c(
          "ol",
          { staticClass: "pl-4 ml-4", staticStyle: { "line-height": "30px" } },
          [
            _c(
              "li",
              {
                staticStyle: { "font-weight": "400" },
                attrs: { "aria-level": "1" },
              },
              [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v("Set up your MetaMask Wallet"),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticStyle: { "font-weight": "400" },
                attrs: { "aria-level": "1" },
              },
              [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "Set up a new token or technically known as a customized\n                  token – this will cover most of the small tokens featured on\n                  this platform"
                  ),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticStyle: { "font-weight": "400" },
                attrs: { "aria-level": "1" },
              },
              [
                _c("span", { staticStyle: { "font-weight": "400" } }, [
                  _vm._v(
                    "How to set up Binance Smart Chain – some cryptocurrencies\n                  will be on the Binance Smart Chain and will require you to\n                  set this up in your wallet."
                  ),
                ]),
              ]
            ),
          ]
        ),
        _vm._v(" "),
        _c("p", [
          _c("b", [
            _vm._v(
              "If you are new to crypto you may be a little intimidated by\n                all these instructions but don’t despair. If you get stuck\n                feel free to "
            ),
          ]),
          _c("a", { attrs: { href: "http://chat@cryptoquestion.tech" } }, [
            _c("b", [_vm._v("message us")]),
          ]),
          _c("b", [
            _vm._v(
              "\n                and we will help you through the process. It will be worth it\n                in the end."
            ),
          ]),
        ]),
        _vm._v(" "),
        _c("p", [
          _c("span", { staticStyle: { "font-weight": "400" } }, [_vm._v(" ")]),
        ]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "Below are the steps you can use to set up your own MetaMask\n                wallet. "
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("b", [_vm._v("Downloading the app"), _c("br")]),
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "You can download the app directly from the App Store or from\n                Google Play for your mobile device. On your personal computer,\n                assuming Google Chrome;"
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("ul", [
      _c(
        "li",
        { staticStyle: { "font-weight": "400" }, attrs: { "aria-level": "1" } },
        [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v(
              "Click “Add Extension” to confirm and MetaMask will be\n                  added"
            ),
          ]),
        ]
      ),
      _vm._v(" "),
      _c(
        "li",
        { staticStyle: { "font-weight": "400" }, attrs: { "aria-level": "1" } },
        [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v(
              "Click on the MetaMask logo, then create a new vault. Set\n                  your password."
            ),
          ]),
        ]
      ),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("b", [_vm._v("Creating your account"), _c("br")])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "Once you’ve opted to create a new account, you will be asked\n                to accept the terms of use, and then prompted to create a new\n                password. Click Create."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("b", [_vm._v("IMPORTANT"), _c("br")]),
      _c("b", [
        _c("br"),
        _vm._v(
          "\n                When MetaMask reveals your secret words, DO NOT FORGET to\n                write them down. "
        ),
      ]),
      _c("b", [_c("br")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("b", [
        _vm._v(
          "This section is bolded so that you don’t accidentally skim\n                and lose access to your wallet forever. "
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("b", [_vm._v("Click the “Reveal Secret Words” button.")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [_c("b", [_vm._v("You will see a 12 word seed phrase. ")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("b", [
        _vm._v(
          "DO NOT store these online, as that can always be a potential\n                security risk. Instead, write these down in a notebook or\n                something you will not misplace. Store it somewhere safe."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [_c("b", [_vm._v(" ")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "Now you’ll need to verify your secret phrase. Again, if you\n                lose it, no one can help you recover the secret phrase, so\n                it’s very important that you have it well-documented. Verify\n                the phrase by selecting the previously generated phrase in\n                order."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "The process of setting up your wallet on mobile is almost\n                entirely the same as the desktop method. Instead of needing to\n                download an extension for your browser, you simply need to go\n                to either the "
        ),
      ]),
      _c(
        "a",
        {
          attrs: {
            href: "https://apps.apple.com/us/app/metamask-blockchain-wallet/id1438144202",
          },
        },
        [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v("App Store"),
          ]),
        ]
      ),
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(" or the "),
      ]),
      _c(
        "a",
        {
          attrs: {
            href: "https://play.google.com/store/apps/details?id=io.metamask&hl=en_US&gl=US",
          },
        },
        [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v("Google Play store"),
          ]),
        ]
      ),
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(" and download MetaMask."),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("b", { staticStyle: { "font-family": "inherit" } }, [
        _vm._v("Now your MetaMask wallet is set up. What’s next?"),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "You can use your wallet to house your NFTs and other tokens,\n                but the unique (and public) wallet address associated with\n                your account also allows other users to send you different\n                kinds of tokens directly to your wallet."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "Your address is easy to identify; both the mobile and desktop\n                version have a button right next to the code that you can use\n                to copy it to your clipboard."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "If you have ETH on another platform like Coinbase, you can\n                also use your address to send your tokens to your MetaMask\n                wallet. To do so, simply go to your Coinbase app, select the\n                Portfolio section, find Ethereum and select “ETH Wallet” and\n                then use the send icon in the top right to input your MetaMask\n                address."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("b", [
        _vm._v(
          "Congratulations! Your MetaMask wallet is set up and you’re\n                ready to get in the game."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h3", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [_vm._v(" ")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "In this guide we will explain how to add a custom token in\n                MetaMask step by step."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "li",
      { staticStyle: { "font-weight": "400" }, attrs: { "aria-level": "1" } },
      [
        _c("span", { staticStyle: { "font-weight": "400" } }, [
          _vm._v(
            "If the token you wish to buy is not listed automatically,\n                  you may add the tokens manually. Select Tokens and click on\n                  “Add Token” button."
          ),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("a", { attrs: { href: "https://etherscan.io/" } }, [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v("EtherScan.io"),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "li",
      { staticStyle: { "font-weight": "400" }, attrs: { "aria-level": "1" } },
      [
        _c("span", { staticStyle: { "font-weight": "400" } }, [
          _vm._v(
            "Enter the Token Contract Address into MetaMask, Token\n                  Symbol and Decimals of Precision and click on »Add\n                  Token«."
          ),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "li",
      { staticStyle: { "font-weight": "400" }, attrs: { "aria-level": "1" } },
      [
        _c("span", { staticStyle: { "font-weight": "400" } }, [
          _vm._v(
            "After you have added your token of desire, you will see the\n                  balance on your account. You can use this method to add any\n                  ERC20 token."
          ),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "wpb_text_column" }, [
      _c("div", { staticClass: "wpb_wrapper" }, [
        _c("p", [_c("b", [_vm._v("Conclusion")])]),
        _vm._v(" "),
        _c("p", [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v(
              "As this Guide has demonstrated, the process of adding custom\n                tokens to MetaMask is straightforward. If you are planning to\n                own multiple ERC20 tokens, you should master this process for\n                future use. If your token is not listed automatically do not\n                get too excited. You should firstly try to custom add\n                it."
            ),
          ]),
        ]),
        _vm._v(" "),
        _c("p", [
          _c("span", { staticStyle: { "font-weight": "400" } }, [
            _vm._v(
              "If you don’t know the address of the token you’re trying to\n                track, ask the person who sent you the tokens. The Ethereum\n                blockchain has countless small tokens, so it’s impossible to\n                know about all of them."
            ),
          ]),
        ]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v("How do you use trade "),
      ]),
      _c(
        "a",
        {
          attrs: {
            href: "https://www.dapp.com/dapps/binance-smart-chain-bsc?sort=4&time=0&type=2?utm_source=md",
          },
        },
        [_c("b", [_vm._v("tokens on BSC")])]
      ),
      _c("span", { staticStyle: { "font-weight": "400" } }, [_vm._v("?")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v("Now that you have an Ethereum wallet, "),
      ]),
      _c("b", [_vm._v("it still won’t work with Binance Smart Chain dapps")]),
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          ". At worst, you could lose funds by sending them to addresses\n                you can’t actually use."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [_vm._v("\n              Let’s change that."), _c("br")])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("strong", [
        _vm._v(
          "3. Click “Add Network” to manually add the Binance Smart\n                Chain one — it doesn’t come packaged with MetaMask."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _vm._v("\n              This is the information you must add:"),
      _c("br"),
      _vm._v("\n              Network Name: Smart Chain"),
      _c("br"),
      _vm._v(" "),
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v("New RPC URL: "),
      ]),
      _c("a", { attrs: { href: "https://bsc-dataseed.binance.org/" } }, [
        _c("span", { staticStyle: { "font-weight": "400" } }, [
          _vm._v("https://bsc-dataseed.binance.org/"),
        ]),
      ]),
      _c("br"),
      _vm._v("\n              ChainID: 56"),
      _c("br"),
      _vm._v("\n              Symbol: BNB"),
      _c("br"),
      _vm._v("\n              Block Explorer URL:\n              "),
      _c("a", { attrs: { href: "https://bscscan.com/" } }, [
        _vm._v("https://bscscan.com"),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("strong", [_vm._v("(An example of connecting to the mainnet.)")]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("strong", [
        _vm._v(
          "4. Once you “Save the Network” and return to the main view,\n                you’ll notice two things: The network has automatically been\n                set to the one you just entered, and the units are no longer\n                denominated in ETH, but in BNB."
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", [
      _c("span", { staticStyle: { "font-weight": "400" } }, [
        _vm._v(
          "Now you have connected your MetaMask wallet to Binance Smart\n                Chain. "
        ),
      ]),
      _c("b", [
        _vm._v(
          "You can add new BSC based tokens by using the same steps as\n                2. above."
        ),
      ]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);