"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["client.Terms"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      charge: 1,
      project: undefined,
      supported_platform: window.supported_platform
    };
  },
  components: {},
  mounted: function mounted() {},
  methods: {},
  watch: {}
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\nh6 {\n  color: #fff;\n  font-weight: bold;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Terms.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/client/views/page/Terms.vue":
/*!**************************************************!*\
  !*** ./resources/js/client/views/page/Terms.vue ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Terms_vue_vue_type_template_id_384d2c44___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Terms.vue?vue&type=template&id=384d2c44& */ "./resources/js/client/views/page/Terms.vue?vue&type=template&id=384d2c44&");
/* harmony import */ var _Terms_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Terms.vue?vue&type=script&lang=js& */ "./resources/js/client/views/page/Terms.vue?vue&type=script&lang=js&");
/* harmony import */ var _Terms_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Terms.vue?vue&type=style&index=0&lang=css& */ "./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Terms_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Terms_vue_vue_type_template_id_384d2c44___WEBPACK_IMPORTED_MODULE_0__.render,
  _Terms_vue_vue_type_template_id_384d2c44___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/client/views/page/Terms.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/client/views/page/Terms.vue?vue&type=script&lang=js&":
/*!***************************************************************************!*\
  !*** ./resources/js/client/views/page/Terms.vue?vue&type=script&lang=js& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Terms.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css&":
/*!***********************************************************************************!*\
  !*** ./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Terms.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/client/views/page/Terms.vue?vue&type=template&id=384d2c44&":
/*!*********************************************************************************!*\
  !*** ./resources/js/client/views/page/Terms.vue?vue&type=template&id=384d2c44& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_template_id_384d2c44___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_template_id_384d2c44___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Terms_vue_vue_type_template_id_384d2c44___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Terms.vue?vue&type=template&id=384d2c44& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=template&id=384d2c44&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=template&id=384d2c44&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/client/views/page/Terms.vue?vue&type=template&id=384d2c44& ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c("section", { staticClass: "banner" }, [
      _c("h1", { staticStyle: { "text-align": "center" } }, [
        _vm._v(_vm._s(_vm.$route.meta.title)),
      ]),
    ]),
    _vm._v(" "),
    _vm._m(0),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      { staticClass: "container-fluid pl-5 pr-5 mt-5 pb-5 mb-2" },
      [
        _c("div", { staticClass: "wrapper pl-4 pr-5 mt-5" }, [
          _c("div", { staticClass: "wpb_wrapper" }, [
            _c("div", { staticClass: "wpb_text_column" }, [
              _c("div", { staticClass: "wpb_wrapper" }, [
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "This privacy policy is for this website and any services\n                provided through the ordinary course of business. Our website\n                is www.moonspark.finance (“The Website”). This policy governs\n                the privacy of both users who choose to use our website or\n                engage with any of our services for both with and without\n                consideration (“Users”). The policy sets out the different\n                areas where user privacy is concerned and outlines the\n                obligations & requirements of the users and the website.\n                Furthermore the way this website processes, stores and\n                protects user data and information will also be detailed\n                within this policy"
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v(" The Website"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "1.1 This website and its owners take a proactive approach to\n                user privacy and ensure the necessary steps are taken to\n                protect the privacy of its users throughout their visiting\n                experience. This website complies to all international\n                national laws and requirements for user privacy."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "2" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v(" Use of Cookies"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "2.1 This website uses cookies to better the user’s experience\n                while visiting the website. Where applicable this website uses\n                a cookie control system allowing the user on their first visit\n                to the website to allow or disallow the use of cookies on\n                their computer / device. This complies with recent legislation\n                requirements for websites to obtain explicit consent from\n                users before leaving behind or reading files such as cookies\n                on a user’s computer / device."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "2.2 Cookies are small files saved to the user’s computer’s\n                hard drive that track, save and store information about the\n                user’s interactions and usage of the website. This allows the\n                website, through its server to provide the users with a\n                tailored experience within this website."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "2.3 Users are advised that if they wish to deny the use and\n                saving of cookies from this website on to their computers hard\n                drive they should take necessary steps within their web\n                browsers security settings to block all cookies from this\n                website and its external serving vendors."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "2.4 This website uses tracking software to monitor its\n                visitors to better understand how they use it. This software\n                is provided by Google Analytics which uses cookies to track\n                visitor usage. The software will save a cookie to your\n                computer’s hard drive in order to track and monitor your\n                engagement and usage of the website, but will not store, save\n                or collect personal information. You can read Google’s privacy\n                policy here for further information\n                http://www.google.com/privacy.html"
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "2.5 Other cookies may be stored to your computer’s hard drive\n                by external vendors when this website uses referral programs,\n                sponsored links or adverts. Such cookies are used for\n                conversion and referral tracking and typically expire after 30\n                days, though some may take longer. No personal information of\n                any kind is stored, saved or collected."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "3" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v("\n                  Contact & Communication"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "3.1 Users contacting this website do so at their own\n                discretion and provide any such personal details requested at\n                their own risk. Your personal information is kept private and\n                stored securely until a time it is no longer required or has\n                no use, as detailed in the Data Protection Laws. Every effort\n                has been made to ensure a safe and secure form to email\n                submission process but advise users using such form to email\n                processes that they do so at their own risk."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "3.2 This website and its owners use any information submitted\n                to provide you with further information about the products /\n                services they offer or to assist you in answering any\n                questions or queries you may have submitted."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "3.3 This includes using your details to subscribe you to any\n                email newsletter program the website operates but only if this\n                was made clear to you and your express permission was granted\n                when submitting any form to the email process. Or whereby you\n                the consumer have previously purchased from or inquired about\n                purchasing from the company a product or service that the\n                email newsletter relates to. This is by no means an entire\n                list of your user rights in regard to receiving email\n                marketing material. Your details are not passed on to any\n                third parties."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "3.4 In sending the company or the website your personal\n                information you are consenting to allow the company to contact\n                you subject to the above conditions. Any data held by the\n                company relating to individuals will be stored and destroyed\n                once a period of 12 months of no communication has occurred\n                between The User and The Website."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "3.5 The Website will never knowingly or willingly pass\n                information it holds on Users (For clarity this includes:\n                clients, prospects, or website users) onto a third party\n                without the consent of the said user."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "4" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v(" Email"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "4.1 From time to time The Website operates various email\n                campaigns programs, (at all times we refer to these as a\n                Newsletter Program) used to inform subscribers about products\n                and services supplied by this website. Users can subscribe\n                through an online automated process should they wish to do so\n                but do so at their own discretion. Some subscriptions may be\n                manually processed through prior written agreement with the\n                user."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "4.2 Subscriptions are taken in compliance with Spam Laws\n                detailed in the Privacy and Electronic Communications\n                Regulations 2003. All personal details relating to\n                subscriptions are held securely and in accordance with the\n                Data Protection Laws. No personal details are passed on to\n                third parties nor shared with companies / people outside of\n                the company that operates this website. Under the Data\n                Protection Laws you may request a copy of personal information\n                held about you by this website’s email newsletter program. A\n                small fee will be payable. If you would like a copy of the\n                information held on you please write to the business address\n                at the bottom of this policy."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "4.3 Email marketing campaigns published by this website or\n                its owners may contain tracking facilities within the actual\n                email. Subscriber activity is tracked and stored in a database\n                for future analysis and evaluation. Such tracked activity may\n                include; the opening of emails, forwarding of emails, the\n                clicking of links within the email content, times, dates and\n                frequency of activity [this is by no far a comprehensive\n                list]."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "4.4 This information is used to refine future email campaigns\n                and supply the user with more relevant content based around\n                their activity."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "4.5 In compliance with EU Spam Laws and the Privacy and\n                Electronic Communications Regulations 2003, and GDPR\n                subscribers are given the opportunity to unsubscribe at any\n                time through an automated system. This process is detailed at\n                the footer of each email campaign. If an automated\n                un-subscription system is unavailable clear instructions on\n                how to un-subscribe will be detailed instead."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "4.6 At all times our email campaigns are run through third\n                party providers such as Mailchimp. Users are advised to refer\n                to the specific terms and conditions attached to these third\n                party companies. Users can easily remove themselves from any\n                email communication by “unsubscribing”."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "4.7 The Website holds no liability as to any damages or\n                losses associated with the use of any third party email\n                service provider. In engaging with the website or continuing\n                use of the website you hereby expressly accept that the\n                Website or its owners holds no such liability"
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "5" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v(" External Links"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "5.1 While every effort has been made to include quality, safe\n                and relevant external links within this website, users are\n                advised to adopt a policy of caution before clicking any\n                external web links mentioned throughout this website.\n                (External links are clickable text / banner / image links to\n                other websites)"
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "5.2 The owners of this website cannot guarantee or verify the\n                contents of any externally linked website despite their best\n                efforts. Users should therefore note they click on external\n                links at their own risk and this website and its owners cannot\n                be held liable for any damages or implications caused by\n                visiting any external links mentioned."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "6" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v("\n                  Adverts and Sponsored Links"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "6.1 This website may contain sponsored links and adverts.\n                These will typically be served through our advertising\n                partners, to whom may have detailed privacy policies relating\n                directly to the adverts they serve."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "6.2 Clicking on any such adverts will send you to the\n                advertisers website through a referral program which may use\n                cookies and will track the number of referrals sent from this\n                website. This may include the use of cookies which may in turn\n                be saved on your computer’s hard drive. Users should therefore\n                note they click on sponsored external links at their own risk\n                and this website and its owners cannot be held liable for any\n                damages or implications caused by visiting any external links\n                mentioned."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "6.3 The owners of this website cannot guarantee or verify the\n                contents of any externally linked website despite their best\n                efforts. Users should therefore note they click on external\n                links at their own risk and this website and its owners cannot\n                be held liable for any damages or implications caused by\n                visiting any external links mentioned."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "7" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v(" Social Media Platforms"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "7.1 Communication, engagement and actions taken through\n                external social media platforms that this website, the\n                company, and its owners participate on are custom to the terms\n                and conditions as well as the privacy policies held with each\n                social media platform respectively."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "7.2 Users are advised to use social media platforms wisely\n                and communicate / engage upon them with due care and caution\n                in regard to their own privacy and personal details. This\n                website nor its owners will ever ask for personal or sensitive\n                information through social media platforms and encourage users\n                wishing to discuss sensitive details to contact them through\n                primary communication channels such as by telephone or\n                email."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "7.3 This website may use social sharing buttons which help\n                share web content directly from web pages to the social media\n                platform in question. Users are advised before using such\n                social sharing buttons that they do so at their own discretion\n                and note that the social media platform may track and save\n                your request to share a web page respectively through your\n                social media platform account."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "7.4 The Website holds responsibility for any and all\n                comments, posts or any other action taken on social media\n                belonging to the company. Social media can easily be\n                identified as belonging to the company by the name of the\n                account on the relevant social media platform. Any and all\n                comments and actions made on social media are not intended to\n                cause offense or serve as a defamatory action. Each and every\n                posting will be checked for accuracy."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "7.5 If you believe your intellectual property rights,\n                personal rights, or any other rights have been infringed by\n                any action on social media you are to notify the company as\n                soon as possible so that the company has an opportunity to\n                rectify and/or remove the post."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "8" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v(
                        "\n                  Shortened Links in Social Media"
                      ),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "8.1 This website and its owners through their social media\n                platform accounts may share web links to relevant web pages.\n                By default some social media platforms shorten lengthy domains\n                and URL’s to third party pages."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "8.2 Users are advised to take caution and good judgement\n                before clicking any shortened urls published on social media\n                platforms by this website and its owners. Despite the best\n                efforts to ensure only genuine urls are published, many social\n                media platforms are prone to spam and hacking and therefore\n                this website and its owners cannot be held liable for any\n                damages or implications caused by visiting any shortened\n                links."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("ol", { attrs: { start: "9" } }, [
                  _c("li", [
                    _c("span", { staticStyle: { "font-weight": "400" } }, [
                      _vm._v(" Contents on our website"),
                    ]),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "This information has not been verified by MoonSpark or\n                CryptoQuestion. Whilst MoonSpark encourages projects to\n                provide accurate and non-misleading information we cannot\n                guarantee the accuracy of the information provided nor be held\n                liable. Investors are urged to always conduct their own due\n                diligence."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Governing Law and Jurisdiction"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "10.1 This privacy policy and any and all items posted on\n                behalf of the website are strictly subject to the Laws of\n                Estonia. Any disagreement that arises under the use of\n                personal information shall be resolved through the Courts of\n                Estonia."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "10.2 The User, in using the website or engaging in social\n                media belonging to the website’s owners, expressly agrees that\n                they are accepting the terms of this privacy policy."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "10.3 If any part of this policy is found to be defective, the\n                remaining elements of the policy shall remain in place."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Special GDPR Notice"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "Citizens of the European Union have the right to track their\n                data under the GDPR regulations brought into force within\n                2018. In using the company website you are hereby agreeing to\n                the following terms and give your consent for such data to be\n                stored as contained in accordance with this GDPR notice."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Data Control Officer"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "You can reach the Data Controller by emailing\n                chat@cryptoquestion.tech. We will aim to reply to you within\n                72 hours. You may request all information and documentation\n                held about you by the company."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Third Parties"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "Data may, from time to time, be shared with third parties for\n                the purposes of conducting a Know Your Client assessment so\n                that participants can prove their location, residence, and\n                citizenship. All parties that have access to your data will be\n                members of the necessary data controlling bodies of their\n                respective countries. For example, the Information\n                Commissioners Office of the United Kingdom."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Safeguards"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "Your data will never be shared with any third party without\n                your consent or court order provided by a court of competent\n                jurisdiction within the country making the request."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Retention Period"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "All data will be stored for a period of a minimum of six\n                months and a maximum of two years."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("The Existence of your rights"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "Nothing within this agreement or the company’s process\n                impacts your rights under the GDPR."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("The right to withdraw consent"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "You may, at any time, request the right to know what\n                information is held by the company relating to you. This\n                request can only be made once as data is only captured once\n                during the registration and participation process. As the\n                information is required for anti-money laundering and\n                antiterrorism laws, we are obliged to keep any and all\n                information relating to you."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("The right to lodge a complaint"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "Citizens of the EU may file a complaint with the relevant\n                data controller within their country. Complaints should first\n                be made to the website so that we can investigate any issues\n                relating to the storage or use of your data."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Source of Data"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "All data collected on you will be done so by your submission\n                of the information and collection of information from the\n                machine you access the website with. Data collection is\n                limited to that contained in our registration method and that\n                information which your computer automatically transmits to our\n                company when accessing our site such as cookies and IP\n                data."
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v("Special California Data Protection Notice"),
                  ]),
                ]),
                _vm._v(" "),
                _c("p", [
                  _c("span", { staticStyle: { "font-weight": "400" } }, [
                    _vm._v(
                      "This organization does not have over $25 million in turnover,\n                does not store data on over 50,000 individuals, and does not\n                collect half or more of our revenue from the sale of personal\n                data"
                    ),
                  ]),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]
    )
  },
]
render._withStripped = true



/***/ })

}]);